Inventory Management System
Name: Mohan Reddy | USN: 25BTRCF037

index.html  -> the website. Double-click to open in any browser. Data is saved in the browser and stays after refresh.
inventory.py -> the original Python program (run: python inventory.py)
